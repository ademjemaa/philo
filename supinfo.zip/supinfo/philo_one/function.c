/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   function.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adjemaa <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/13 16:11:58 by adjemaa           #+#    #+#             */
/*   Updated: 2021/05/13 16:12:43 by adjemaa          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

unsigned long	the_time(void)
{
	struct timeval	eat;

	gettimeofday(&eat, NULL);
	return ((eat.tv_sec * 1000) + (eat.tv_usec / 1000));
}

void	pick_up_forks()
{

}

void	drop_forks()
{

}

void	*function(void *args)
{
	t_params	*tab;

	tab = (t_params *)args;
	ft_locked_print("test", tab->id, tab->stru);
	//your code
	//this is a recursive function, but when is it called and when does it choose to return ?
	function(args);
	return (0);
}
