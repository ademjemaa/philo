/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_uno.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adjemaa <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/13 16:24:41 by adjemaa           #+#    #+#             */
/*   Updated: 2021/05/13 16:27:14 by adjemaa          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	free_all()
{

}

int	check_stats(t_condi *stru)
{
	int	index;
	int	i;

	index = 0;
	(void)index;
	i = -1;
	while (++i < stru->philo)
	{
		//your code
	}
	//more code
	return (1);
}

int	init_vars(char **argv, int argc, t_condi *stru)
{
	unsigned long	current;
	int				i;

	i = -1;

	if (init_philos(argv, argc, stru) == 0)
		return (0);
	stru->philos = malloc(sizeof(t_phil) * stru->philo);
	current = the_time();
	//your code
	while (++i < stru->philo)
	{
		//your code
	}
	(void)current;
	return (1);
}

int	main(int argc, char **argv)
{
	int			i;
	void		*ret;
	t_condi		stru;
	t_params	**tab;

	i = -1;
	if (init_vars(argv, argc, &stru) == 0)
		return (ft_putstr("config error\n"));
	tab = create_params_tab(&stru);
	while (++i < stru.philo)
	{
		pthread_create(&stru.philos[i].thread_id, NULL,
			function, (void*)tab[i]);
		pthread_detach(stru.philos[i].thread_id);
		usleep(100);
	}
	while(1);
	(void)ret;
	// while (check_stats(&stru))
	// 	i = -1;
	// while (++i < stru.philo)
	// 	pthread_join(stru.philos[i].thread_id, &ret);
	// usleep(200000);
	// free_all(&stru, tab);
}
